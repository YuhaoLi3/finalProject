public class TransactionHistory {
    public static String history;
    public TransactionHistory(){
    }
    public static void addHistory(String his){
        history+=his;
    }








}
